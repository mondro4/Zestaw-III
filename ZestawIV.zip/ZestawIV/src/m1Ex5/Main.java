package m1Ex5;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {


        Travels Paris = new Travels("Paris", 7, 4500);
        Travels Egypt = new Travels("Egypt", 7, 5000);
        Travels Greece = new Travels("Greece", 4, 3000);
        Travels Germany = new Travels("Germany", 3, 1200);
        Travels Croatia = new Travels("Croatia", 10, 4000);
        Travels Australia = new Travels("Australia", 14, 9000);
        Travels Brazil = new Travels("Brazil", 9, 8500);
        Travels Mexico = new Travels("Mexico", 10, 10000);
        Travels CzechRepublic = new Travels("CzechRepublic", 2, 700);


       Set<Travels> TravelsSet = new HashSet<>();
        TravelsSet.add(Paris);
        TravelsSet.add(Egypt);
        TravelsSet.add(Greece);
        TravelsSet.add(Germany);
        TravelsSet.add(Croatia);
        TravelsSet.add(Australia);
        TravelsSet.add(Brazil);
        TravelsSet.add(Mexico);
        TravelsSet.add(CzechRepublic);
        System.out.println(TravelsSet);

        System.out.println("Możliwe kierunki wycieczek to: " + Paris.getDestination() + ", " + Egypt.getDestination() + ", " + Germany.getDestination() + ", " + Croatia.getDestination() + ", " + CzechRepublic.getDestination() + ", " + Greece.getDestination() + ", " + Australia.getDestination() + ", " + Brazil.getDestination() + ", " + Mexico.getDestination());


        if (Paris.getDuration() > 4) {
            System.out.println();
        }
    }
}


