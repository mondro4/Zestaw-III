package m1Ex5;

public class Travels {

    private String destination;
    private int duration;
    private int price;

    public Travels(String destination, int duration, int price) {
        this.destination = destination;
        this.duration = duration;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Travels{" +
                "destination='" + destination + '\'' +
                ", duration=" + duration +
                ", price=" + price +
                '}';
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDestination() {
        return destination;
    }

    public int getDuration() {
        return duration;
    }

    public int getPrice() {
        return price;
    }
}
// dedykowane rozwiązanie odnośnie różnych wycieczek dotyczy innej kolekcji niż lista. Również nie jest powiedziane, że muszą w tej kolekcji byc wycieczki konkretnie. Uzyskanie wycieczek dłuższych niż 4 dni to może być zwykła iteracja po ewementach wycieczek i sprawdzanie getterem ich długości - wyśiwetlanie gdy wartość > 4 . Prosze również nie zapominać o konwencji! Na pierwszy rzut oka myślałem że TravelsList to klasa która ma metodę statyczną add ! Nazwy obiektów również proszę trzymać w konwencji. Metoda statyczna getDuration z klasy Travels prawdopodobnie by się nie sprawdziła, poniewaz nie byłaby zbindowana z żadną konkretną wycieczką.
//Klasa Travels to zwykłe POJO - jest poprawna.