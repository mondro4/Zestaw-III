package m2Ex5;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> mapOfFlashcard =  new TreeMap<>(); //Collections.reverseOrder()- odwróc kolejność, zeby wymieszac stwórz własny komparator
        while (true) {
            System.out.println("Podaj słowo w języku polskim. Zakończ: exit");
            String polWord = scanner.nextLine();
            if (polWord.equals("exit")) {
                break;
            }
            System.out.println("Podaj słowo w języku angielskim");
            String angWord = scanner.nextLine();

            mapOfFlashcard.put(polWord, angWord);

            }
        System.out.println("Podaj słowo w języku polskim, którego tłumaczenie na język angielski chcesz zobaczyć");
        String wordFromUser= scanner.nextLine();
        System.out.println(wordFromUser +  " w języku angielski to : " + mapOfFlashcard.get(wordFromUser));
        System.out.println(mapOfFlashcard.getOrDefault(wordFromUser,"Nie odnaleziono słowa"));

        Set set = mapOfFlashcard.entrySet();
        Iterator i = set.iterator();

        while (i.hasNext()) {
            Map.Entry mapEntry = (Map.Entry)i.next();
            System.out.print(mapEntry.getKey() + ": ");
            System.out.println(mapEntry.getValue());
        }
        System.out.println("Sprawdzenie wiedzy");
        Scanner scanner1= new Scanner(System.in);
        System.out.println("Wybierz poziom trudności kursu: basic lub advanced");
        String choose = scanner.nextLine();
    }




}




        
        
