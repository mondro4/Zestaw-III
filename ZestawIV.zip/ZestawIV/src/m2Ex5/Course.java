package m2Ex5;

import java.util.Scanner;

public class Course {
    int basicCourse;
    int advancedCourse;

    public Course(int basicCourse, int advancedCourse) {
        this.basicCourse = basicCourse;
        this.advancedCourse = advancedCourse;

    }

    public void practise() {

    }


    public void exam() {
    }
}