package m2Ex3;

import java.util.*;

public class m2Ex3 {


    public static void main(String[] args) {
        Set<Integer> integerSet = new HashSet<>();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Podaj liczby. Koniec:0");
            try {
                int n1 = scanner.nextInt();
                if (n1 == 997) {
                    throw new IllegalArgumentException();
                }
                if (n1 == 0) {
                    break;
                }
                    integerSet.add(n1);
                System.out.println(integerSet);

            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Podałeś literę");

            }
            System.out.println(integerSet);

        }


    }
}