package m2Ex1;

public class Grocery {
    private double income;
    private String foodStaff;
    private String nameOfProduct;

    public Grocery(double income, String foodStaff) {
        this.income = income;
        this.foodStaff = foodStaff;
    }

    public double getIncome() {
        return income;
    }

    public String getFoodStaff() {
        return foodStaff;
    }
}
