package m2Ex1;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Map<String, Double> foodStaffs = new LinkedHashMap<>();

        foodStaffs.put("mleko", 3.0);
        foodStaffs.put("ser", 4.5);
        foodStaffs.put("woda", 2.5);
        foodStaffs.put("chleb", 3.8);
        foodStaffs.put("czekolada", 4.0);
        foodStaffs.put("pieczarki", 8.2);
        foodStaffs.put("papryka", 9.5);
        foodStaffs.put("jajka", 11.0);
        foodStaffs.put("wędlina", 5.5);
        foodStaffs.put("bułka", 0.9);
        foodStaffs.put("oliwa", 10.0);
        foodStaffs.put("orzechy", 6.7);
        foodStaffs.put("sól", 5.7);
        foodStaffs.put("cukier", 4.4);
        foodStaffs.put("kasza", 3.0);

        for (Map.Entry<String, Double> pair : foodStaffs.entrySet()) {
            System.out.println(pair.getKey() + " kosztuje " + pair.getValue() + " zl");
        }
    }
}

