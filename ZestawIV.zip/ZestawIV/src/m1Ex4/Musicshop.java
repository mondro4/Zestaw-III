package m1Ex4;

public abstract class Musicshop {

    private String brand;
    private String name;
    private String materials;
    private double price;

    public Musicshop(String brand, String name, String materials, double price) {
        this.brand = brand;
        this.name = name;
        this.materials = materials;
        this.price = price;
    }

    public String getBrand() { return brand; }

    public double getPrice() {
        return price;
    }

    public String getMaterials() { return materials;}
    public String getName() { return name;}

    @Override
    public String toString() {
        return "Musicshop{" +
                "brand='" + brand + '\'' +
                ", name='" + name + '\'' +
                ", materials='" + materials + '\'' +
                ", price=" + price +
                '}';
    }

//    enum BrandEnum {
//        IBANEZ(1954, "Marka gitar elektrycznych, akustycznych, klasycznych i basowych oraz sprzętu muzycznego"),
//        TANGLEWOOD(1988, "Producent instrumentów strunowych, w tym gitar elektrycznych i akustycznych i klasycznych, gitar basowych, banjo, mandolin, ukuleli i wzmacniaczy gitarowych."),
//        D_ADDARIO(1974, "Producent głównie strun do instrumentów muzycznych,ale i instrumentów głównie do gitar."),
//        STENTOR (1910, "Marka angielska o ponad 100-letniej tradycji."),
//        YAMAHA (1955, "Działalność grupy Yamaha obejmuje: produkcję i sprzedaż: instrumentów muzycznych (m.in. fortepiany i pianina, syntezatory, zestawy perkusyjne, gitary itp.)"),
//        GRETSCH(1883,"Charakterystyczne elementy marki Gretsch, więcej brzmienia i więcej wydajności niż inne modele z pólki początkowej."),
//        PEARL(1946, "Japońska marka założona w 1946 roku przez Katsumi Yanagisawa. Pearl to jeden z liderów instrumentów perkusyjnych oraz zestawów perkusyjnych znanych na całym świecie." );
//
//
//        private int dateOfCreation;
//        private String description;
//
//        BrandEnum(int dateOfCreation, String description) {
//            this.dateOfCreation = dateOfCreation;
//            this.description = description;
//
//        }
//
//        public int getDateOfCreation() {
//            return dateOfCreation;
//        }
//
//        public String getDescription() {
//            return description;
//        }
}

