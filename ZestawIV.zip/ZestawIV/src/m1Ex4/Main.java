package m1Ex4;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
//        Guitars guitars1 = new Guitars("Ibanez", "Ibanez XYZ", "wood", 2000);
        Guitars guitars2 = new Guitars("Tanglewood", "Tanglewood MJX", "oakWood", 8000);
//        Guitars guitars3 = new Guitars("D_addario", "D_ADDARIO 123", "ebonyWood", 5000);

//        Violin violin1 = new Violin("Stentor", "Stentor X", "ebonyWood", 5000);
        Violin violin2 = new Violin("Yamaha", "Yamaha", "beechWood", 7000);

        Drums drums1 = new Drums("Gretsch", "Gretsch Ace X", "precious metals", 8500);
//        Drums drums2 = new Drums("Pearl", "Pearl 879", "metal", 6500);

        Person person1 = new Person(15000, "Violin");
//        Person person2 = new Person(15000, "Drums");
//        Person person3 = new Person(12000, "Violin");

        Scanner scaner = new Scanner(System.in);
        System.out.println("Który instrument chciałbyś kupić? (Guitar,Violin,Drums)");
        String answer = scaner.nextLine();
        switch (answer) {
            case "Guitar":
                System.out.println("Czy chcesz poznać szczegóły? (tak/nie)");
                String odp = scaner.nextLine();
                switch (odp) {
                    case "nie":
                        break;
                    case "tak":
                        System.out.println();
                        System.out.println("Marka instrumentu to: " + guitars2.getBrand() +" Materiał, z którego wykonano instrument "+ guitars2.getMaterials() + " Cena to: "+ guitars2.getPrice());
                        System.out.println("Czy interesują cię marki?");
                        String odp2 = scaner.nextLine();
                        switch (odp2) {
                            case "nie":
                                break;
                            case "tak":
                                System.out.println("Marka D'Addario " + "Istnieje od " + Guitars.BrandEnumGuitars.D_ADDARIO.getDateOfCreation() + " roku " + Guitars.BrandEnumGuitars.D_ADDARIO.getDescription());
                                System.out.println("Marka Ibanez " + "Istnieje od " + Guitars.BrandEnumGuitars.IBANEZ.getDateOfCreation() + " roku " + Guitars.BrandEnumGuitars.IBANEZ.getDescription());
                                System.out.println("Marka Tanglewood " + "Istnieje od " + Guitars.BrandEnumGuitars.TANGLEWOOD.getDateOfCreation() + " roku " + Guitars.BrandEnumGuitars.TANGLEWOOD.getDescription());
                                System.out.println("Udzielam rabatu 10% ");
                                System.out.println("Cena po  rabacie: " + (guitars2.getPrice()- (guitars2.getPrice()*0.10)));
                        }
                }
                break;
            case "Violin":
                System.out.println("Czy chcesz poznać szczegóły? (tak/nie)");
                odp = scaner.nextLine();
                switch (odp) {
                    case "nie":
                        break;
                    case "tak":
                        System.out.println("Marka instrumentu to: " + violin2.getBrand() +" Materiał, z którego wykonano instrument "+ violin2.getMaterials() + " Cena to: "+ violin2.getPrice());
                        System.out.println("Czy interesują cię marki?");
                        String odp3 = scaner.nextLine();
                        switch (odp3) {
                            case "nie":
                                break;
                            case "tak":
                                System.out.println("Marka Stentor " + "Istnieje od " +Violin.BrandEnumViolin.STENTOR.getDateOfCreation() +" roku " +  Violin.BrandEnumViolin.STENTOR.getDescription());
                                System.out.println("Marka Yamaha " + "Istnieje od " +Violin.BrandEnumViolin.YAMAHA.getDateOfCreation() + " roku " +  Violin.BrandEnumViolin.YAMAHA.getDescription());
                                System.out.println("Udzielam rabatu 10%");
                                System.out.println("Cena po  rabacie: " +(violin2.getPrice()- (violin2.getPrice()*0.10)));
                        }
                }
                break;
            case "Drums":
                System.out.println("Czy chcesz poznać szczegóły? (tak/nie)");
                odp = scaner.nextLine();
                switch (odp) {
                    case "nie":
                        break;
                    case "tak":
                        System.out.println("Marka instrumentu to: " + drums1.getBrand() +" Materiał, z którego wykonano instrument "+ drums1.getMaterials() + " Cena to: "+ drums1.getPrice());
                        System.out.println("Czy interesują cię marki?");
                        String odp4 = scaner.nextLine();
                        switch (odp4) {
                            case "nie":
                                break;
                            case "tak":
                                System.out.println("Marka Gretsch " + "Istnieje od " +Drums.BrandEnumDrums.GRETSCH.getDateOfCreation() + " roku " +  Drums.BrandEnumDrums.GRETSCH.getDescription());
                                System.out.println("Marka Pearl " + "Istnieje od " +Drums.BrandEnumDrums.PEARL.getDateOfCreation() + " roku " +  Drums.BrandEnumDrums.PEARL.getDescription());
                                System.out.println("Udzielam rabatu 10%");
                                System.out.println("Cena po  rabacie: " + (drums1.getPrice()- (drums1.getPrice()*0.10)));
                        }
                }
                break;
            default:
                System.out.println("Nie mamy takiego instrumentu");

        }
        System.out.println("Czy chcesz kupić instrument?");
        String buy = scaner.nextLine();
        switch (buy) {
            case "nie":
                System.out.println("Polecamy się na przyszłość. Do widzenia");
                break;
            case "tak":
                System.out.println("Potwierdz jaki instrument chcesz zakupić");
                String confirmChoose = scaner.nextLine();
                switch (confirmChoose) {
                    case "Drums":
                        System.out.println("Czy udzielono Ci rabatu? tak/nie");
                        String discounthaveDrums = scaner.nextLine();
                        switch (discounthaveDrums) {
                            case "nie":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Drums.BrandEnumDrums.GRETSCH + ". " + "Zapłaciłeś " + drums1.getPrice() + "Zostało Ci " + (person1.budget - drums1.getPrice()));
                                person1.myInstrument.replace("Violin", "Drums");
                                break;
                            case "tak":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Drums.BrandEnumDrums.GRETSCH + ". " + "Zapłaciłeś " + (drums1.getPrice() - (drums1.getPrice() * 0.10)) + "Zostało Ci " + (person1.budget - drums1.getPrice() - (drums1.getPrice() * 0.10)));
                                person1.myInstrument.replace("Violin", "Drums");
                                break;

                            case "Violin":
                        System.out.println("Czy udzielono Ci rabatu? tak/nie");
                        String discounthaveViolin = scaner.nextLine();
                        switch (discounthaveViolin) {
                            case "nie":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Violin.BrandEnumViolin.YAMAHA + ". " + "Zapłaciłeś " + violin2.getPrice() + "Zostało Ci " + (person1.budget - violin2.getPrice()));
                                person1.myInstrument.replace("Violin", "Violin");
                                break;
                            case "tak":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Violin.BrandEnumViolin.YAMAHA + ". " + "Zapłaciłeś " + (violin2.getPrice() - (violin2.getPrice() * 0.10)) + "Zostało Ci " + (person1.budget - violin2.getPrice() - (violin2.getPrice() * 0.10)));
                                person1.myInstrument.replace("Violin", "Violin");
                                break;
                    case "Guitar":
                        System.out.println("Czy udzielono Ci rabatu? tak/nie");
                        String discounthaveGuitar = scaner.nextLine();
                        switch (discounthaveGuitar) {
                            case "nie":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Guitars.BrandEnumGuitars.TANGLEWOOD + ". " + "Zapłaciłeś " + guitars2.getPrice() + "Zostało Ci " + (person1.budget - guitars2.getPrice()));
                                person1.myInstrument.replace("Violin", "Guitar");
                                break;
                            case "tak":
                                System.out.println("Dziękujemy za zakup. Zakupiłeś " + Guitars.BrandEnumGuitars.TANGLEWOOD + ". " + "Zapłaciłeś " + (guitars2.getPrice() - (guitars2.getPrice() * 0.10)) + "Zostało Ci " + (person1.budget - guitars2.getPrice() - (guitars2.getPrice() * 0.10)));
                                person1.myInstrument.replace("Violin", "Guitar");

                            break;


                                        }


                                }

                        }
                }
        }}}