package m1Ex4;

public class Drums extends Musicshop {
    public Drums(String brand, String name, String materials, double price) {
        super(brand, name, materials, price);
    }

    enum BrandEnumDrums {

        GRETSCH(1883, "Charakterystyczne elementy marki Gretsch, więcej brzmienia i więcej wydajności niż inne modele z pólki początkowej."),
        PEARL(1946, "Japońska marka założona w 1946 roku przez Katsumi Yanagisawa. Pearl to jeden z liderów instrumentów perkusyjnych oraz zestawów perkusyjnych znanych na całym świecie.");

        private int dateOfCreation;
        private String description;

        BrandEnumDrums(int dateOfCreation, String description) {
            this.dateOfCreation = dateOfCreation;
            this.description = description;

        }

        public int getDateOfCreation() {
            return dateOfCreation;
        }

        public String getDescription() {
            return description;
        }
    }
}
