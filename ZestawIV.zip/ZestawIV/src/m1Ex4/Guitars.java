package m1Ex4;

public class Guitars extends Musicshop {


    public Guitars(String brand, String name, String materials, double price) {
        super(brand, name, materials, price);
    }

    enum BrandEnumGuitars {
        IBANEZ(1954, "Marka gitar elektrycznych, akustycznych, klasycznych i basowych oraz sprzętu muzycznego"),
        TANGLEWOOD(1988, "Producent instrumentów strunowych, w tym gitar elektrycznych i akustycznych i klasycznych, gitar basowych, banjo, mandolin, ukuleli i wzmacniaczy gitarowych."),
        D_ADDARIO(1974, "Producent głównie strun do instrumentów muzycznych,ale i instrumentów głównie do gitar.");

        private int dateOfCreation;
        private String description;

        BrandEnumGuitars (int dateOfCreation, String description) {
            this.dateOfCreation = dateOfCreation;
            this.description = description;
        }

        public int getDateOfCreation() {
            return dateOfCreation;
        }

        public String getDescription() {
            return description;
        }
    }


}