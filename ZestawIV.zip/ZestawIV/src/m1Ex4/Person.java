package m1Ex4;

public class Person {
    double budget = 15000;
    String myInstrument;

    public Person(double budget, String myInstrument) {
        this.budget = budget;
        this.myInstrument= myInstrument;
    }

    public double getBudget(double v) {
        return budget;
    }
}
