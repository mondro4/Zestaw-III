package m1Ex4;

public class Violin extends Musicshop {
    public Violin(String brand, String name, String materials, double price) {
        super(brand, name, materials, price);
    }

    private int dateOfCreation;
    private String description;

    enum BrandEnumViolin {

        STENTOR(1910, "Marka angielska o ponad 100-letniej tradycji."),
        YAMAHA(1955, "Działalność grupy Yamaha obejmuje: produkcję i sprzedaż: instrumentów muzycznych (m.in. fortepiany i pianina, syntezatory, zestawy perkusyjne, gitary itp.)");

        private int dateOfCreation;
        private String description;

        BrandEnumViolin(int dateOfCreation, String description) {
            this.dateOfCreation = dateOfCreation;
            this.description = description;
        }

        public int getDateOfCreation() {
            return dateOfCreation;
        }

        public String getDescription() {
            return description;
        }

    }
}