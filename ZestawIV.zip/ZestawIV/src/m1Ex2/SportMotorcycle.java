package m1Ex2;

public class SportMotorcycle extends Motorcycle {
    public SportMotorcycle(int POWER_VALUE, String NAME) {
        super(POWER_VALUE, NAME);
    }


    @Override
    public void moto() {
        super.moto();
        System.out.println("This is my sport motorcycle");
    }
}