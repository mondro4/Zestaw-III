package m1Ex2;


public class Main {
    public static void main(String[] args) {

        Motorcycle Yamaha = new Motorcycle(152, "Yamahha");
        SportMotorcycle Kawasaki = new SportMotorcycle(250, "Kawasaki");


        System.out.println("Marka to " + Yamaha.getName() + " " + "Moc : " + Yamaha.getPOWER_VALUE());
        System.out.println("Marka to " + Kawasaki.getName() + " " + "Moc : " + Kawasaki.getPOWER_VALUE());


    }

}
