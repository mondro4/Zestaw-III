package m1Ex2;

public class Motorcycle {
    private final int POWER_VALUE;
    private final String NAME;

    public Motorcycle(int POWER_VALUE, String name) {
        this.POWER_VALUE= POWER_VALUE;
        this.NAME=name;
    }

    public int getPOWER_VALUE() {
        return POWER_VALUE;
    }

    public String getName() {
        return NAME;
    }

    public void moto(){
        System.out.println("This is my motorcycle");
    }

    @Override
    public String toString() {
        return "Motorcycle{" +
                "POWER_VALUE=" + POWER_VALUE +
                '}';
    }
}

