package m3Ex1;

import java.util.*;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> mapOfCountry = new LinkedHashMap<>();
        int count = 0;
        while (true) {

            System.out.println("Podaj nazwę państwa");
            String nameOfCountry = scanner.nextLine();

            if (nameOfCountry == ("-")) {
                break;

            }
            System.out.println("Podaj nazwę stolicy");
            String capital = scanner.nextLine();

            mapOfCountry.put(nameOfCountry, capital);
            System.out.println(mapOfCountry.entrySet());

            for (Map.Entry<String, String> pair : mapOfCountry.entrySet()) {
                System.out.println("Stolicą " + pair.getKey() + " jest " + pair.getValue());

                System.out.println("Podaj nazwę państwa");
                if (nameOfCountry.equals(pair.getKey())) {
                    System.out.println(pair.getValue());
                } else {
                    System.out.println("Nie ma takiego klucza");


                }
            }
        }
    }
}


//    Armenia Erywań
//    Australia Canberra
//    Austria Wiedeń
//    Azerbejdżan Baku
//    Belgia Bruksela
//    Belize Belmopan
//    Brazylia Brasília
//    Brunei Bandar
//    Seri Begawan
//    Bułgaria Sofia
//    Burkina Faso Wagadugu
//    Chorwacja Zagrzeb
//    Cypr Nikozja
//    Czad Ndżamena
//    Dania Kopenhaga
//    Demokratyczna Republika Konga Kinszasa
//    Dominika Roseau
//    Grecja Ateny
//    Grenada Saint George’s
//    Gruzja Tbilisi
//    Gujana Georgetown