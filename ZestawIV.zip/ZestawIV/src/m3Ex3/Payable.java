package m3Ex3;

public interface Payable {
    double getPaymentAmount();

}
