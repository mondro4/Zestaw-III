package m3Ex3;

public abstract class HourlyEmployee extends Employee {
    private double ratePerHour;
    private double numberOfHours;

    public HourlyEmployee(String name, String surname, double ratePerHour, double numberOfHours) {
        super(name, surname);
        this.ratePerHour = ratePerHour;
        this.numberOfHours = numberOfHours;
    }

    public void setNumberOfHours(double numberOfHours) {
        if (numberOfHours > 168) {
            throw new IndexOutOfBoundsException("Maksymalna liczba godzin w miesiącu to 168");
        }
    }

    public double getRatePerHour() {
        return ratePerHour;
    }

    public double getNumberOfHours() {
        return numberOfHours;
    }

    public void setRatePerHour(double ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    @Override
    public double earnings() {
        if (getNumberOfHours() <= 40) {
            return getNumberOfHours() * getRatePerHour();
        } else {
            return 40 * getRatePerHour() + (getNumberOfHours() - 40) * getRatePerHour() * 1.5;


        }
    }
}


