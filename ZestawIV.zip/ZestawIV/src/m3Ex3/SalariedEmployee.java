package m3Ex3;

public abstract class SalariedEmployee extends Employee {
    private double earn;

    public SalariedEmployee(String name, String surname, double earn) {
        super(name, surname);
        this.earn = earn;
    }

    public void setEarn(double earn) {
        this.earn = earn;
    }

    public double getEarn() {
        return earn;
    }

    @Override
    public String toString() {
        return "SalariedEmployee{" +
                "earn=" + earn +
                '}';
    }

    @Override
    public double earnings() {
        return getEarn();
    }
}
