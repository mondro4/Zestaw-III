package m3Ex3;

public class Invoice implements Payable {
    private final double priceForPieces;
    private final double amount;
    private final String batchDescription;
    private final int batchNumber;

    public Invoice(double priceForPieces, double amount, String batchDescription, int batchNumber) {
        this.priceForPieces = priceForPieces;
        this.amount = amount;
        this.batchDescription = batchDescription;
        this.batchNumber = batchNumber;
    }

    public double getPriceForPieces() {
        return priceForPieces;
    }

    public double getAmount() {
        return amount;
    }

    public String getBatchDescription() {
        return batchDescription;
    }

    public int getBatchNumber() {
        return batchNumber;
    }


    @Override
    public String toString() {
        return "Invoice{" +
                "priceForPieces=" + priceForPieces +
                ", amount=" + amount +
                ", batchDescription='" + batchDescription + '\'' +
                ", batchNumber=" + batchNumber +
                '}';
    }

    @Override
    public double getPaymentAmount() {
        return getAmount() * getPriceForPieces();
    }
}
