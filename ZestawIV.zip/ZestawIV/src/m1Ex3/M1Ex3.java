package m1Ex3;

import java.util.Locale;
import java.util.Scanner;

public class M1Ex3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
        System.out.println("Podaj  pierwszą liczbę");
        double n1 = scanner.nextDouble();
        System.out.println("Podaj drugą liczbę");
        double n2 = scanner.nextDouble();

        try {
            if (n2 == 0) {
                throw new ArithmeticException();
            }
            System.out.println("Wynik dzielenia to " + n1 / n2);
        } catch (ArithmeticException e) {
            System.out.println("Nie wolno dzielić przez 0");

        }

    }
}

