package m2Ex2;

public class Warehouse extends Building {

    private int availability;


    public Warehouse(String address, int size, double temperature, int availability) {
        super(address, size, temperature);
        this.availability = availability;
    }


}
