package m2Ex2;

public class House extends Building {
    private String residents;

    public House(String address, int size, double temperature, String residents) {
        super(address, size, temperature);
        this.residents = residents;
    }
}
