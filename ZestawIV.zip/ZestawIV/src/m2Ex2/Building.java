package m2Ex2;

public class Building {
    private String address;
    private int size;
    private double temperature;

    public Building(String address) {
        this.address = "Konfederacka 23";
    }

    public Building(String address, int size) {
        super();
        this.size = size;

        }

    public Building(String address, int size, double temperature) {
      super();
        this.temperature = temperature;
    }
}


