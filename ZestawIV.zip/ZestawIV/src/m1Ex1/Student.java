package m1Ex1;

public class Student extends CzlonekSpolecznosci {
}
