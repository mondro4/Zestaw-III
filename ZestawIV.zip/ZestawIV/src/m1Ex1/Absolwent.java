package m1Ex1;

public class Absolwent extends Student{
}
