package m1Ex1;

public class Wykladowca extends NauczycieAkademicki{
}
