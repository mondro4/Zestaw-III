package m1Ex1;

public class Pracownik extends CzlonekSpolecznosci {
}
