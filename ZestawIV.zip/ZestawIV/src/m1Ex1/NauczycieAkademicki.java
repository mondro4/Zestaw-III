package m1Ex1;

public class NauczycieAkademicki extends Pracownik {
}
