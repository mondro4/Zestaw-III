package m1Ex1;

public class CzlonekSpolecznosci {
}
