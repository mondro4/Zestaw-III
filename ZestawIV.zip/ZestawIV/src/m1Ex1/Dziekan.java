package m1Ex1;

public class Dziekan extends NauczycieAkademicki {
}
