package m1Ex1;

public class PracownikTechniczny extends Pracownik{
}
