package m3Ex4;

public class main {
    public static void main(String[] args) {
        M3Ex4 number = new M3Ex4(3, 3);
        number.Create();
        int[][] pack = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        System.out.println("Output ");
        for (int i = 0; i < pack.length; i++) {
            for (int j = 0; j < pack[i].length; j++) {
                System.out.print(pack[i][j] + " ");
            }
            System.out.println();
        }
    }
}
