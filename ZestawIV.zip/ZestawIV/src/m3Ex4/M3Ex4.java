package m3Ex4;

public class M3Ex4 {
        int kolumny;
        int wiersze;
        int wartosc;
        int[][] tab;

        public M3Ex4(int kolumny, int wiersze) {
            this.kolumny=kolumny;
            this.wiersze=wiersze;
        }
        public void Create(){
            this.tab=new int[this.kolumny][this.wiersze];
            for(int i=0;i<this.kolumny;i++)
                for(int j=0;j<this.wiersze;j++){
                    this.tab[i][j]=wartosc;
                }
        }


    }

