package m2Exercise6;

import java.util.Random;

public class Game {
    
    static void Game(){
        Random random = new Random();
    int downBound = random.nextInt(50);
    int upBound = random.nextInt(500)+500;

    }
}
