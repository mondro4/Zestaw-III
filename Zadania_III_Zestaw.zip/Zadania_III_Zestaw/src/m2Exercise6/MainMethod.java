package m2Exercise6;

public class MainMethod {
}
