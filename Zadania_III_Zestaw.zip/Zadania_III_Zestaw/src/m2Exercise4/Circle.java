package m2Exercise4;

import com.sun.org.apache.xpath.internal.objects.XString;

public class Circle {
    private static double radius = 1.5;
    private static String color = "red";
    double area;

    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;

    }

    public static double getRadius() {
        return radius;
    }

    public static String getColor() {
        return color;
    }

}
