package m2Exercise4;

public class MainMethod {
    public static void main(String[] args) {
        System.out.println(Circle.getRadius());
        System.out.println("Area is = " + Math.PI * Circle.getRadius() * Circle.getRadius() + " Circle color " + Circle.getColor());


        }
    }