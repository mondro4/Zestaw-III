package allSmallExercise;

import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class ExercisesIII {

    public static void m1Exercise1() {
//        int[] array = new int[]{1, 2, 3, 7, 9, 67, 90, 55, 78,56,54,87};
//
////        for (int i = 0; i < array.length; i++) {
////            System.out.println(array[i]);
//
//            for (int x : array) {
//                System.out.println(x);

//        String[] arrayOfStrings = {'a', 'b', 'c'};

//        for (int i = 0; i < arrayOfStrings.length; i++) ;
//            arrayOfStrings[i] = i + 1;
//
//
//            for (String element : arrayOfStrings) {
//                System.out.println(element);
//
//            }
//            }
    }

    public static void m1Exercise2() {
//        String name1 = "Piotrek";
//        String name2 = "Magda";
//        String name3 = "Hubert";
//        String name4 = "Stanisław";
//        String name5 = "Ola";
//
//        System.out.printf(String.format("%225s", "Imię to " +  name1));
//        System.out.println();
//        System.out.printf(String.format("%225s", "Imię to " +  name2));
//        System.out.println();
//        System.out.printf(String.format("%225s", "Imię to " +  name3));
//        System.out.println();
//        System.out.printf(String.format("%225s", "Imię to " +  name4));
//        System.out.println();
//        System.out.printf(String.format("%225s", "Imię to " +  name5));
//        System.out.println();

    }


    public static void m1Exercise3() {
//        Random random = new Random();
//        double ramdomNumber = random.nextInt(5) + 10;
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Określ liczbę miejsc po przeciku.");
//        int n = scanner.nextInt();
//        switch (n) {
//            case 1:
//                System.out.printf(String.format("%.1f", ramdomNumber));
//                break;
//            case 2:
//                System.out.printf(String.format("%.2f", ramdomNumber));
//                break;
//            case 3:
//                System.out.printf(String.format("%.3f", ramdomNumber));
//                break;
//            case 4:
//                System.out.printf(String.format("%.4f", ramdomNumber));
//                break;
//            default:
//                System.out.println(ramdomNumber);
//
//        }

//    }
    }


    public static void m2Exercise2() {
//        double[] array = new double[5];
//        array[0] = 5.900987;
//        array[1] = 10.76548;
//        array[2] = 15.87659;
//        array[3] = 20.87654;
//        array[4] = 25.87532;
//
//        for (double i = 0; i < array.length; i++) {
//            System.out.printf(String.format("%.4f", array[(int) i]));
//...
//        for (double element : array ) {
//            System.out.printf(String.format("%.5f", array[(int) element]));
//             System.out.printf(String.format("%.4f",element));
// ...
//        double[] array = {5.900987, 10.76548, 15.87659, 20.87654, 25.87532};
//        for (double i = 0; i < array.length; i++) {
//            System.out.println(array[(int) i]);
//            // index tablicy 4 to 5 miejsc po przecinku, 3 to 4, 2 to 3 1 to 2 0 to 1


        }


//
//    public static void m2Exercise4() {
//
//    }
//
//    public static void m2Exercise5() {
//
//    }

    public static void main(String[] args) {
        m1Exercise1();
        m1Exercise2();
        m1Exercise3();

        m2Exercise2();
//        m2Exercise4();
//        m2Exercise5();
//        m2Exercise6();


//        m3Exercise2();
//        m3Exercise3();
//        m3Exercise4();
//        m3Exercise5();
//        m3Exercise6();
//        m3Exercise7();

//        m4Exercise1();
//        m4Exercise2();
//        m4Exercise3();
//        m4Exercise4();
//        m4Exercise5();
//        m4Exercise6();

    }
}




