package m1Exercise4;

public class MainMethod {
    public static void main(String[] args) {

        Point point1 = new Point(10, 8);
        Point point2 = new Point(7, 20);

        System.out.println(point1.getX());
        System.out.println(point1.getY());
        System.out.println();
        System.out.println(point2.getX());
        System.out.println(point2.getY());

        double distance = Point.distance(point1, point2);
        System.out.printf("Odlegosc pomiędzy wyznaczonymi punktami = %.3f %n", distance);
    }

}
