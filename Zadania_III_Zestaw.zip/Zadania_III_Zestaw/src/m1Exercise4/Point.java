package m1Exercise4;

public class Point {
    private int x;
    private int y;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public static double distance(Point point1, Point point2) {
        int point1X = point1.x;
        int point2X = point2.x;
        int point1Y = point1.y;
        int point2Y = point2.y;

        double distance = Math.sqrt(Math.pow(point1X - point2X, 2) + Math.pow(point1Y - point2Y, 2));

        return distance;
    }
}
