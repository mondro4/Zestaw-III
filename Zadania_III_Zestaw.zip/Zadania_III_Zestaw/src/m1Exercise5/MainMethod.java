package m1Exercise5;

public class MainMethod {
    public static void main(String[] args) {
        System.out.println("Marka samochodu to : " + Car.CarEnum.FIAT.getBrand() + "." + " Obroty silnika wynoszą: " + Car.CarEnum.FIAT.getTurns() + "." + " Data produkcji: " + Car.CarEnum.FIAT.getYear());
        System.out.println("Marka samochodu to : " + Car.CarEnum.HONDA.getBrand() + "." + " Obroty silnika wynoszą: " + Car.CarEnum.HONDA.getTurns() + "." + " Data produkcji: " + Car.CarEnum.HONDA.getYear());
        System.out.println("Marka samochodu to : " + Car.CarEnum.BMW.getBrand() + "." + " Obroty silnika wynoszą: " + Car.CarEnum.BMW.getTurns() + "." + " Data produkcji: " + Car.CarEnum.BMW.getYear());


    }
}

