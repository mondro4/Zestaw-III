package m1Exercise5;


public class Car {

    enum CarEnum {
        FIAT("Fiat", 1500, 1990),
        HONDA("Honda", 2000, 2010),
        BMW("BMW", 2500, 2020);


        private String brand;
        private int year;
        private int turns;

        CarEnum(String brand, int turns, int year) {
            this.brand = brand;
            this.turns = turns;
            this.year = year;
        }

        public String getBrand() {
            return brand;
        }

        public void setBrand(String brand) {
            this.brand = brand;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        public int getTurns() {
            return turns;
        }

        public void setTurns(int turns) {
            this.turns = turns;
        }

//        public String getBrand() {return brand;}
//        public int getTurn() { return turns; }
//        public int getYear() { return year; }


    }


}


