package m5Exercise1;

public class Barrel {
    private double amount;
    private final String type;
    private boolean opened;
    public final static double MUG_SIZE = 0.7;

    {
        System.out.println("Hey people! The barrel has just arrived!");
    }

    public Barrel(String type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    public boolean isOpened() {
        return opened;
    }

    public double getAmount() {
        return amount;
    }

    public void setOpened(boolean opened) {
        this.opened = opened;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Beer createBeer() {
        System.out.println("Creation the beer amount of " +
                type + " beer is: " + amount);
        if (amount < MUG_SIZE) {
            System.out.println("Not enough :(");
            return new Beer("juice", 0);
        }

        return new Beer(type, Beer.getAlcoholForType(type));
    }
}
