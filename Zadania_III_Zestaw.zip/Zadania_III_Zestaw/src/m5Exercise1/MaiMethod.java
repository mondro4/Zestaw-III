package m5Exercise1;

public class MaiMethod {
    public static void main(String[] args) {
        Barrel bFree1 = new Barrel(Beer.TYPE_FREE, 3);
        Barrel bPorter1 = new Barrel(Beer.TYPE_PORTER, 4);
        Barrel bLager1 = new Barrel(Beer.TYPE_LAGER, 7);

        Student st1 = new Student(3);
        Student st2 = new Student(5);
        Student st3 = new Student();

        Beer beerFree = bFree1.createBeer();
        System.out.println(st1.getState());
        String message1 = st1.drinkBeer(beerFree);
        System.out.println(message1);
        String state1 = st1.getState();
        System.out.println(state1);

        Beer beerPorter1 = bPorter1.createBeer();
        st1.drinkBeer(beerPorter1);
        String state2 = st1.getState();
        System.out.println(state2);
        Beer beerFree2 = bFree1.createBeer();
        st1.drinkBeer(beerFree2);
        while (true) {
            Beer beerPorterN = bPorter1.createBeer();
            if (Student.getPermillsForAlcohol(
                    beerPorterN.getAlcohol()
            ) + st2.getPermills() > st2.getMaxPermills()
                    || bPorter1.getAmount() < Barrel.MUG_SIZE
            ) {
                System.out.println(st2.drinkBeer(beerPorterN));
                break;
            }
            st2.drinkBeer(beerPorterN);
        }
        System.out.println(st2.getState());

        while (true) {
            Beer beerLagerN = bLager1.createBeer();
            if (Student.getPermillsForAlcohol(
                    beerLagerN.getAlcohol()
            ) + st2.getPermills() > st2.getMaxPermills()
                    || bLager1.getAmount() < Barrel.MUG_SIZE
            ) {
                System.out.println(st2.drinkBeer(beerLagerN));
                break;
            }
            System.out.println(st2.drinkBeer(beerLagerN));
        }
        System.out.println(st2.getState());
    }
}
