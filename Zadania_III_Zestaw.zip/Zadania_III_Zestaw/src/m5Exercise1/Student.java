package m5Exercise1;

public class Student {

    private double permills;
    private double cheerfulness;
    private double maxPermills = 4.5;


    public Student() {
    }

    public Student(double maxPermills) {
        this.maxPermills = maxPermills;

    }

    public String getState() {

        return "Permills: " + permills + "\n" + "Cheerfulness: " + cheerfulness + "\n" + "maxPermills: " + maxPermills + "\n";
    }

    public String drinkBeer(Beer beer) {
        if (permills + getPermillsForAlcohol(beer.getAlcohol()) > this.maxPermills) {
            cheerfulness -= getPermillsForAlcohol(beer.getAlcohol());

            return "I'm done! It's end.";
        }
        permills += getPermillsForAlcohol(beer.getAlcohol());
        cheerfulness += getPermillsForAlcohol(beer.getAlcohol());

        return "I'm so pleased";
    }

    public static double getPermillsForAlcohol(double beerAlcohol) {
        return beerAlcohol;
    }

    public double getPermills() {
        return permills;
    }

    public double getMaxPermills() {
        return maxPermills;
    }


}


