package m3Exercise4;

public class MainMethod {
    public static void main(String[] args) {

        new Ball(Ball.FOOTBALL_TYPE);
        new Ball(Ball.VOLLEYBALL_TYPE);
        new Ball(Ball.BOWLINGBALL_TYPE);
        Ball ball1 = new Ball("tennisball");
        Ball ball2 = new Ball("basketball");
        Ball ball3 = new Ball("baseball");
        Ball.getStatistics();

        System.out.println(ball1.getType());
        System.out.println(ball2.getType());
        System.out.println(ball3.getType());

        Juggler juggler = new Juggler();
        juggler.play();
        juggler.play(ball1, ball2, ball3);
        juggler.play(ball1, ball2, ball3, ball3);
        juggler.play(ball2);
        juggler.play(new Ball(Ball.BOWLINGBALL_TYPE));

    }
}
