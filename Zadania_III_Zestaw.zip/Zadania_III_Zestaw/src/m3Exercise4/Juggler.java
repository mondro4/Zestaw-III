package m3Exercise4;

public class Juggler {

    public void play(Ball... balls) {

        System.out.println("Start game");
        for (Ball ball: balls) {
            if(ball.getType().equals(Ball.BOWLINGBALL_TYPE)) {
                System.out.println(Ball.BOWLINGBALL_TYPE);
            }
            System.out.println(ball.getType());
        }

    }
}
