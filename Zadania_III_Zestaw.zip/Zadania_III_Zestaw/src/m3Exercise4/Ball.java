package m3Exercise4;

public class Ball {

        public final static String VOLLEYBALL_TYPE = "volleyball";
        public final static String FOOTBALL_TYPE = "football";
        public final static String BOWLINGBALL_TYPE= "bowlingball";

        static int volleyballCounter;
        static int footballCounter;
        static int bowlingballCounter;


        private final String type;

        public static void getStatistics() {
            System.out.println("volleyballs: " + volleyballCounter);
            System.out.println("footballs: " + footballCounter);
            System.out.println("bowlingballs: " + bowlingballCounter);

        }

        public Ball(String type) {
            switch (type) {
                case VOLLEYBALL_TYPE:
                    volleyballCounter++;
                    break;
                case FOOTBALL_TYPE:
                    footballCounter++;
                    break;
                case BOWLINGBALL_TYPE:
                    bowlingballCounter++;
                    break;
                default:

            }
            this.type = type;
            System.out.println("Nowa Ball (type = " +
                    type + ")");
        }


        public String getType() {
            return type;
        }

        public static int getVolleyballCounter() {
            return volleyballCounter;
        }

        public static void setVolleyballCounter(int volleyballCounter) {
            Ball.volleyballCounter = volleyballCounter;
        }

        public static int getFootballCounter() {
            return footballCounter;
        }

        public static void setFootballCounter(int footballCounter) {
            Ball.footballCounter = footballCounter;
        }

        public static int getBowlingballCounter() {
            return bowlingballCounter;
        }

        public static void setBasketballCounter(int basketballCounter) {
            Ball.bowlingballCounter = basketballCounter;
        }


    }


