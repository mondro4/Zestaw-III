package m2Exercise1;

public class Main {
    public static void main(String[] args) {

//        String result = validateData("Hubert");              //a
//        System.out.println(result);
//        result = validateData("Natalia");
//        System.out.println(result);
//        result = validateData("Hubert", 40);             //b
//        System.out.println(result);
//        result = validateData("Władek", 15);
//        System.out.println(result);
//        result = validateData("Hubert", 40, "Nowak");             //b
//        System.out.println(result);
//        result = validateData("Magda");
//        System.out.println(result);
//        result = validateData("Władek", 15);
//        System.out.println(result);
//        result = validateData("Pawel", 15, "Kowalski");
//        System.out.println(result);
    }
}