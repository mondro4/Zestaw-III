package m2Exercise1;

public class validateData {
    String isPrioryty;
    int numberPriority;


    private static String validateData(String isPriority) {
        return "Validated data " + isPriority;
    }

    private static String validateData(String isPriority, int numberPriority) {
        return "Validated data " + isPriority + "Number priority is " + numberPriority;
    }

    private static String validateData(String name, int age, String surname) {
        return "Mam na imie " + name + ". Moje nazwisko to " + surname + ". Metoda jest przeciazona \"jeszcze bardziej\". Moj wiek to " + age + " lat";
    }


}
