//package m2Exercise3;
//
//import java.util.Random;
//import java.util.Scanner;
//
//public class Employee {
//    private String name;
//    private String surname;
//    private int salary;
//
//    public Employee(String name, String surname, int salary) {
//        name = name;
//        surname = surname;
//        salary = salary;
//    }
//
//
//    public String show() {
//        return ("Hello " + name + surname + " in our company! Your " + salary + " is " + salary + ".");
//
//    }
//
//    public static String hire() {
//        Scanner scanner= new Scanner(System.in);
//        System.out.println("Podaj imię");
//        name = scanner.nextLine() ;
//        System.out.println("Podaj nazwisko");
//        surname = scanner.nextLine() ;
//        Random random= new Random();
//        salary =  random.nextInt(6000;7000;8000);
//
//    }
//
//
//
