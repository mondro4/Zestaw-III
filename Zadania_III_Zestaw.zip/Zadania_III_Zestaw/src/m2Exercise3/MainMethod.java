package m2Exercise3;

public class MainMethod {
    public static void main(String[] args) {

    }
}
