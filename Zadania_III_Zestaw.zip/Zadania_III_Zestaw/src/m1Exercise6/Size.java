package m1Exercise6;

public class Size {

    enum ShowSize {
        S("rozmiar S"),
        M("rozmiar M"),
        L("rozmiar L");


        private String description;


        ShowSize(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    }