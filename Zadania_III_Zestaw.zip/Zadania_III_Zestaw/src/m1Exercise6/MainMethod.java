package m1Exercise6;

public class MainMethod {
    public static void main(String[] args) {
        System.out.println(Size.ShowSize.S.getDescription());
        System.out.println(Size.ShowSize.M.getDescription());
        System.out.println(Size.ShowSize.L.getDescription());
    }
}
