package m3Exercise1;

public class Triangle {

    double a;
    double b;
    double c;
    Point p1;
    Point p2;
    Point p3;


    Triangle(Point p1, Point p2, Point p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        a = Point.distance(p1, p2);
        b = Point.distance(p2, p3);
        c = Point.distance(p1, p3);
    }

    void show() {
        p1.show();
        p2.show();
        p3.show();
        System.out.println("Długość boków: " + a + ", " + b + ", " + c);
        System.out.println("Obwód: " + circumreference());
    }

    double circumreference() {
        return a + b + c;
    }

    static double circumreference(Point a, Point b, Point c) {
        return Point.distance(a, b) +
                Point.distance(b, c) +
                Point.distance(a, c);
    }
}

