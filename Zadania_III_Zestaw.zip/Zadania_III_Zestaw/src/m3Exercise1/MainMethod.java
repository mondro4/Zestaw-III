package m3Exercise1;

public class MainMethod {
    public static void main(String[] args) {
        Point p1 = new Point(8, 5, 3);
        Point p2 = new Point(2, 3, 4);
        Point p3 = new Point(5, 7, 1);
        Triangle triangle = new Triangle(p1, p2, p3);
        triangle.show();
        System.out.println(Triangle.circumreference(p1, p2, p3));
    }
    }


