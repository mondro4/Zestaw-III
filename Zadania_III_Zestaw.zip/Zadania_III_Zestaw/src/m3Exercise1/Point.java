package m3Exercise1;

public class Point {

        double x;
        double y;
        double z;
        boolean b1;
        int i1;
        char c1;
        String s1;
        Point p1;

        Point(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        void show() {
            System.out.println("(" + x + ", " + y + ", " + z + ")");
            System.out.print("(b1: " + b1 + ", i1: " + i1 + ", c1: " + c1);
            System.out.println(", s1: " + s1 + ", p1: " + p1 + ")");
        }

        static double circumreference(Point p1, Point p2, Point p3) {
            double a = distance(p1, p2);
            double b = distance(p2, p3);
            double c = distance(p1, p3);

            return a + b + c;
        }

        static double distance(Point p1, Point p2) {
            return Math.sqrt((p1.x - p2.x)*(p1.x - p2.x) +
                    (p1.y - p2.y)*(p1.y - p2.y) +
                    (p1.z - p2.z)*(p1.z - p2.z)
            );
        }
}
