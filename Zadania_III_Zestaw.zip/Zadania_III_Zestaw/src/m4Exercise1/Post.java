package m4Exercise1;

public class Post {
    public void sendLetter(Sender send) {
        String letterAddress = send.getLetterAddress();
        System.out.println("Sending post from " + send.getAddress() +
                " to " + letterAddress
        );
    }
}
