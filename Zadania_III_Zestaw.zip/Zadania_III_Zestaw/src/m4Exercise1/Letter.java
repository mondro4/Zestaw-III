package m4Exercise1;

public class Letter {

    String address;

    String getAddress() {
        return address;
    }

    public void setAddress(String Address) {
        this.address = Address;
    }
}

