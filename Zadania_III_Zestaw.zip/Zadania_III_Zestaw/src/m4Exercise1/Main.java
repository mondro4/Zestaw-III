package m4Exercise1;

public class Main {
    public static void main(String[] args) {
        Post post1 = new Post();
        Post post2 = new Post();

        Sender sender1 = new Sender();
        sender1.setAddress("ul. Jana III Sobieskiego 9/11, 76-200 Słupsk");

        Sender sender2 = new Sender();
        sender2.setAddress("aleja Pokoju 67, 00-030 Warszwa");

        Letter letter1 = new Letter();
        letter1.setAddress("ul. Konfederacka  23/5, 30-306 Kraków");

        Letter letter2 = new Letter();
        letter2.setAddress("ul. Zagrody 11/3, 68-113 Chełmno");

        sender1.setLetter(letter1);
        post1.sendLetter(sender1);
        sender2.setLetter(letter2);
        post2.sendLetter(sender2);
    }
}
