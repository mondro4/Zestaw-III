public class Sportman {
    private String name;
    private String surname;
    private String discipline;
    private String team;
    private int skills;

    public Sportman(String name, String surname, String discipline, String team, int skills) {
        this.name = name;
        this.surname = surname;
        this.discipline = discipline;
        this.team = team;
        this.skills = skills;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getTeam() {
        return team;
    }

    public int getSkills() {
        return skills;
    }

    @Override
    public String toString() {
        return "Sportman{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", discipline='" + discipline + '\'' +
                ", team='" + team + '\'' +
                ", skills=" + skills +
                '}';
    }
}
