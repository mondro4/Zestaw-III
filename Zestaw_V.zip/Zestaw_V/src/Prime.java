import java.util.stream.IntStream;

public class Prime {

    public static boolean isPrime(int n) {
        return IntStream.rangeClosed(2, (int) Math.sqrt(n))
                .allMatch(s -> n % s != 0);

    }

}