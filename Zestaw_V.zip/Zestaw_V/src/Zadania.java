import com.sun.beans.editors.StringEditor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class Zadania {


    public static void main(String[] args) {
        Ex1();
        Ex2();
        Ex3();
        Ex4();
        Ex5();
        Ex6();
        Ex7();
        Ex8();
        Ex9();
        Ex10();
//        Ex11();
        Ex12();
        Ex13();
        Ex14();
        Ex15();
//        Ex16();
        Ex17();
        Ex18();
        Ex19();
        Ex20();
        Ex21();
        Ex22();
//        Ex23();
//        Ex24();
        Ex25();
//        Ex26();
//        Ex27();

        ExB1();
//        ExB2();
//        ExB3();
//        ExB4();
//        ExB5();
//        ExB6();

    }

    private static void Ex1() {
//        IntStream.rangeClosed(3, 10)
//                .forEach(System.out::println);
    }

    private static void Ex2() {
//        List<Integer> listInt = new ArrayList<>();
//        Random randomNumber = new Random(20);
//        for (int i = 0; i < 4; i++) {
//            listInt.add(randomNumber.nextInt(20));
//            System.out.println(listInt);
//
//        }
    }

    private static void Ex3() {
//        IntStream.rangeClosed(10, 20)
//                .map(s -> s * 2)
//                .limit(6)
//                .forEach(System.out::println);
    }

    private static void Ex4() {
//        int sum;
//
//        int[] ints = {6, -7, 20, -2, 15};
//        sum = IntStream.of(ints)
//                .sum();
//        System.out.println("Suma wszystkich intów wynosi: " + sum);
    }

    private static void Ex5() {
//        IntStream.range(0, 15)
//                .filter(s -> s % 3 == 0)
//                .forEach(System.out::println);
    }

    private static void Ex6() {
//        int sum;
//
//        int[] ints = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
//        sum = IntStream.of(ints)
//                .map(s -> s * s)
//                .sum();
//        System.out.println("Suma kwadratów wszystkich intów wynosi: " + sum);

    }

    private static void Ex7() {
//        IntStream.range(10, 20)
//                .sorted()
//                .collect(Collectors.toList()));
    }


    private static void Ex8() {
//        IntStream.range(10, 20)
//                .mapToObj(s -> " " + s)
//                .forEach(System.out::print);
    }

    private static void Ex9() {
//        List<Integer> List4Integers = new ArrayList<>(Arrays.asList(4, 2, 8, 7));
//        List4Integers.stream()
//                .filter(s -> s > 5)
//                .forEach(System.out::println);
    }

    private static void Ex10() {
//        int min;
//        int max;
//        int[] ints = {4, 2, 8, 7, 21, -8, 49, 6, 44, 17, -2};
//        min = IntStream.of(ints)
//                .min()
//                .getAsInt();
//
//        max = IntStream.of(ints)
//                .max()
//                .getAsInt();
//        System.out.println("Minimalna wrtość strumienia " + min);
//        System.out.println("Maksymalna wartość strumienia " + max);
    }

//    private static void Ex11() {
//        List<Integer> integers = new ArrayList<>(Arrays.asList(5, 2, 3, 7, 9));
//        integers.stream()
//                .map(s ->
//
//
//        int factorial;
//        int n;
//        for (int i = 1; i <= n; i++) {
//        factorial *= i;
//    }
//        System.out.println("Silnia z " + n + " to " + factorial);
//
//    }

    private static void Ex12() {
//        List<Integer> randomNumbersList = new ArrayList<>();
//        Random random = new Random(50);
//        for (int i = 0; i < 8; i++) {
//            randomNumbersList.add(random.nextInt(50));
//        }
//        int[] tempList = new int[randomNumbersList.size()];
//        for (int i = 0; i < randomNumbersList.size(); i++) {
//            tempList[i] = randomNumbersList.get(i);
//        }
//        System.out.println(randomNumbersList);
//        System.out.println("Średnia arytmetyczna z wylosowanych liczb wynosi: " + IntStream.of(tempList).average().getAsDouble());
    }

    private static void Ex13() {
//        List<Integer> escapeNegatives = new ArrayList<>(Arrays.asList(-7, -10, -4, -1, 0, 12, 5, 7, -5, 8, 10));
//            escapeNegatives.stream()
//                    .filter(s -> s >= 0)
//                    .sorted(Comparator.reverseOrder())
//                    .forEach(s -> System.out.println(s));
    }


    private static void Ex14() {
//        List<String> listString = new ArrayList<>(Arrays.asList("horse", "frog", "zebra", "chimpanzee", "lion", "snake", "lizard"));
//        listString.stream()
//                .filter(s -> !s.contains("z"))
//                .forEach(System.out::println);
    }


    private static void Ex15() {
//        List<String> list = new ArrayList<>();
//        list.add("woda");
//        list.add("mysz");
//        list.add("lampka");
//        list.add("telefon");
//        list.add("podkładka");
//        list.add("szczoteczka");
//        list.add("krasnoludek");
//        list.add("torebka");
//
//        list.forEach(System.out::println);
//
//        boolean greaterThan5 = list.stream()
//                .allMatch(s -> s.length() > 5);
//
//        System.out.println(greaterThan5);
    }

//    private static void Ex16() {
//
//    }

    private static void Ex17() {
//        IntStream.rangeClosed(0, 50)
//                .filter(s -> s % 2 == 0)
//                .mapToDouble(s -> s)
//                .mapToObj(s -> "Liczba " + s / 5)
//                .forEach(s -> System.out.println(s + ", "));

    }

    private static void Ex18() {
//        User user = new User("Jacek", 25, 90);
//        User user2 = new User("Magda", 40, 85);
//        User user3 = new User("Karol", 18, 50);
//        User user4 = new User("Henryk", 29, 75);
//        User user5 = new User("Ala", 10, 30);
//
//        List<User> users = new ArrayList<>(Arrays.asList(user, user2, user3, user4, user5));
//
//        users.stream()
//                .filter(s -> s.getWeight() > 0)
//                .limit(1)
//                .forEach(s -> System.out.println("Najwięcej waży " + s.getName() + " " + s.getWeight() + " kg"));
//
//        users.stream()
//                .filter(s -> s.getAge() > 18)
//                .forEach(s -> System.out.println("D " + s.getName()));

    }

    private static void Ex19() {
//        double[] tab = {2.2, 3.6, 7.0, 8.6, 5.5, 3.3, 4.5, 6.8, 3.7, 2.3};
//
//        OptionalDouble average;
//        average = DoubleStream.of(tab)
//                .average();
//        System.out.println("Średnia wynosi: " + average.getAsDouble());
//
//        Arrays.stream(tab)
//                .sorted()
//                .filter(s -> s > average.getAsDouble())
//                .forEach(System.out::println);
    }

    private static void Ex20() {
//        List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 6, 9, 4, 4, 23, 11, 21, 8, 4, 9, 0);
//
//        List<Integer> integersAsList = integers.stream()
//                .distinct()
//                .collect(Collectors.toList());
//        integersAsList.forEach(System.out::println);

    }

    private static void Ex21() {
//        String[] tabString = {"morze", "wichury", "mewy", "piasek"};
//        Arrays.stream(tabString)
//                .sorted()
//                .forEach(s -> System.out.println(s));

    }

    private static void Ex22() {
//        Sportman sportman1 = new Sportman("Marek", "Król", "Siatkówka", "Orły Pomorza", 4);
//        Sportman sportman2 = new Sportman("Tomasz", "Mysz", "Piłka nożna", "FC Talenty", 9);
//        Sportman sportman3 = new Sportman("Henryk", "Rok", "Piłka nożna", "FC Talenty", 8);
//        Sportman sportman4 = new Sportman("Mateusz", "Para", "Siatkówka", "Orły Pomorza", 6);
//        Sportman sportman5 = new Sportman("Krzysztof", "Zyd", "Piłka nożna", "FC Talenty", 6);
//        Sportman sportman6 = new Sportman("Mirosłam", "Mróz", "Piłka ręczna", "Torpedy", 9);
//        Sportman sportman7 = new Sportman("Kazimierz", "Pyra", "Piłka nożna", "FC Talenty", 3);
//
//
//        List<Sportman> sportmanList = new ArrayList(Arrays.asList(sportman1, sportman2, sportman3, sportman4, sportman5, sportman6, sportman7));
//        sportmanList.forEach(s -> {
//
//        });
//        sportmanList.stream()
//                .filter(s -> s.getSkills() > 5)
//                .forEach(s -> System.out.println(" Sportowcy ze wspólczynnikiem umiejętności powyżej 5 to: " + s.getName() + " jego wynik to: " + s.getSkills()));
//
//        sportmanList.stream()
//                .filter(s -> s.getDiscipline().contains("Piłka nożna"))
//                .sorted()
//                .forEach(s -> System.out.println("Piłkarze posortowani pod wzggłędem umiejętności " + s.getName() + " " + s.getSurname() + " "));
//
//
//        sportmanList.stream()
//                .map(s -> "Nazwa zespołu: " + s.getTeam() + "," + " Imię " + s.getName() + " Umiejętności wynoszą " + +s.getSkills())
//                .forEach(s -> System.out.println(s));
//
    }

    private static void Ex25() {

//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Podaj liczbę");
//        int n = scanner.nextInt();
//
//        IntStream.iterate(2, s -> s + 1)
//                .filter(Prime::isPrime)
//                .limit(n)
//                .forEach(System.out::println);
    }

    private static void ExB1() {
        //Napisz program, w którym wpiszesz do pliku numbers.txt 10 losowych liczb, a
        //następnie zsumujesz ich wartość i wypiszesz na górę pliku napis : Suma wynosi
        //(suma).

//        Random random = new Random();
//        for (int i = 0; i < 10; i++) {
//            int randomNumber = random.nextInt(50);
//            System.out.println(randomNumber);
//            try {
//
//                File file = new File("numbers.txt");
//                PrintWriter writer = new PrintWriter(file);
//                writer.println(randomNumber);
//                writer.close();
//            } catch (FileNotFoundException e) {
//                System.out.println(e.getMessage());
//
//            }
//        }
//        try (Scanner scanner= new Scanner(file)){
//
//        }
    }


}
